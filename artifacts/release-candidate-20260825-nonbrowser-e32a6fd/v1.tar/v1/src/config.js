import net from 'node:net';
import { z } from 'zod';

const booleanString = z
  .enum(['true', 'false'])
  .transform((value) => value === 'true');

export function isEnvTrue(value) {
  return String(value ?? '').trim().toLowerCase() === 'true';
}

const optionalNonEmptyString = z.preprocess(
  (value) => String(value ?? '').trim() || undefined,
  z.string().min(1).optional()
);

const databaseFields = {
  DATABASE_URL: z.string().url().startsWith('mysql://'),
  DATABASE_TLS: booleanString.default(false),
  DATABASE_TLS_CA_BASE64: z.string().trim().min(1).optional()
};

const baseSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  HOST: z.string().trim().min(1).default('127.0.0.1'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3100),
  TRUST_PROXY: booleanString.default(false),
  ...databaseFields,
  SESSION_ENCRYPTION_KEY_BASE64: z
    .string()
    .min(1)
    .refine((value) => {
      try {
        return Buffer.from(value, 'base64').length === 32;
      } catch {
        return false;
      }
    }, 'SESSION_ENCRYPTION_KEY_BASE64 must decode to exactly 32 bytes'),
  CDK_HASH_KEY_V1_BASE64: z.string().trim().min(1),
  CDK_RECOVERY_KEY_BASE64: z.string().trim().min(1),
  CDK_DELIVERY_HMAC_KEY_BASE64: z.string().trim().min(1).optional(),
  HNSKJ_API_BASE_URL: z.string().url().default('https://card.hnskj.vip/api/open/v1'),
  HNSKJ_API_KEY: z.string().trim().min(1).optional(),
  CARD_INTAKE_PAN_HMAC_KEY_BASE64: z.string().trim().min(1).optional(),
  PAYMENT_REFERENCE_HMAC_KEY_BASE64: z.string().trim().min(1).optional(),
  ADMIN_HOST: z.string().trim().min(1).max(253).optional(),
  ADMIN_PASSWORD_HASH: z.string().trim()
    .regex(/^scrypt-v1\$[A-Za-z0-9_-]{22}\$[A-Za-z0-9_-]{86}$/)
    .optional(),
  ADMIN_SESSION_SECRET_BASE64: z.string().trim().min(1).optional()
});

const runtimeDatabaseSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  ...databaseFields
}).superRefine((value, context) => validateDatabaseConfig(value, context, {
  urlKey: 'DATABASE_URL',
  tlsKey: 'DATABASE_TLS',
  caKey: 'DATABASE_TLS_CA_BASE64'
}));

const barkNotificationSchema = runtimeDatabaseSchema.extend({
  BARK_ENABLED: booleanString.default(false),
  BARK_SERVER_URL: z.string().url().default('https://api.day.app'),
  BARK_DEVICE_KEY: optionalNonEmptyString,
  BARK_GROUP: z.string().trim().min(1).max(64).default('AI充值业务'),
  BARK_POLL_INTERVAL_MS: z.coerce.number().int().min(500).max(60_000).default(5_000),
  BARK_REQUEST_TIMEOUT_MS: z.coerce.number().int().min(1_000).max(60_000).default(10_000),
  BARK_MAX_ATTEMPTS: z.coerce.number().int().min(1).max(20).default(8)
}).superRefine((value, context) => {
  if (value.BARK_ENABLED && !value.BARK_DEVICE_KEY) {
    context.addIssue({
      code: 'custom',
      path: ['BARK_DEVICE_KEY'],
      message: 'is required when BARK_ENABLED=true'
    });
  }
});

const cdkSecuritySchema = z.object({
  CDK_HASH_KEY_V1_BASE64: z.string().trim().min(1),
  CDK_RECOVERY_KEY_BASE64: z.string().trim().min(1)
}).superRefine((value, context) => validateCdkSecurityConfig(value, context));

const migrationSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  DATABASE_URL: z.string().url().startsWith('mysql://').optional(),
  MIGRATION_DATABASE_URL: z.string().url().startsWith('mysql://'),
  MIGRATION_DATABASE_TLS: booleanString.default(false),
  MIGRATION_DATABASE_TLS_CA_BASE64: z.string().trim().min(1).optional()
}).superRefine((value, context) => {
  validateDatabaseConfig(value, context, {
    urlKey: 'MIGRATION_DATABASE_URL',
    tlsKey: 'MIGRATION_DATABASE_TLS',
    caKey: 'MIGRATION_DATABASE_TLS_CA_BASE64'
  });
  const runtimeUsername = value.DATABASE_URL ? databaseUsername(value.DATABASE_URL) : null;
  const migrationUsername = databaseUsername(value.MIGRATION_DATABASE_URL);
  if (value.DATABASE_URL && runtimeUsername === null) {
    context.addIssue({
      code: 'custom',
      path: ['DATABASE_URL'],
      message: 'credentials must use valid URL percent-encoding'
    });
  } else if (value.NODE_ENV === 'production' && value.DATABASE_URL && !runtimeUsername) {
    context.addIssue({
      code: 'custom',
      path: ['DATABASE_URL'],
      message: 'must include a database username in production'
    });
  }
  if (
    value.NODE_ENV === 'production'
    && value.DATABASE_URL
    && runtimeUsername !== null
    && migrationUsername !== null
    && runtimeUsername === migrationUsername
  ) {
    context.addIssue({
      code: 'custom',
      path: ['MIGRATION_DATABASE_URL'],
      message: 'must use a username separate from DATABASE_URL in production'
    });
  }
});

function validateAdminConfig(value, context) {
  const hasPassword = Boolean(value.ADMIN_PASSWORD_HASH);
  const hasSecret = Boolean(value.ADMIN_SESSION_SECRET_BASE64);
  if (hasPassword !== hasSecret) {
    context.addIssue({
      code: 'custom',
      path: ['ADMIN_PASSWORD_HASH'],
      message: 'ADMIN_PASSWORD_HASH and ADMIN_SESSION_SECRET_BASE64 must be configured together'
    });
  }
  if (hasSecret) {
    try {
      if (Buffer.from(value.ADMIN_SESSION_SECRET_BASE64, 'base64').length !== 32) throw new Error();
    } catch {
      context.addIssue({
        code: 'custom',
        path: ['ADMIN_SESSION_SECRET_BASE64'],
        message: 'must decode to exactly 32 bytes'
      });
    }
  }
}

function validateCdkSecurityConfig(value, context) {
  for (const key of ['CDK_HASH_KEY_V1_BASE64', 'CDK_RECOVERY_KEY_BASE64']) {
    try {
      if (Buffer.from(value[key], 'base64').length !== 32) throw new Error();
    } catch {
      context.addIssue({
        code: 'custom',
        path: [key],
        message: 'must decode to exactly 32 bytes'
      });
    }
  }
  if (
    value.CDK_HASH_KEY_V1_BASE64
    && value.CDK_RECOVERY_KEY_BASE64
    && value.CDK_HASH_KEY_V1_BASE64 === value.CDK_RECOVERY_KEY_BASE64
  ) {
    context.addIssue({
      code: 'custom',
      path: ['CDK_RECOVERY_KEY_BASE64'],
      message: 'must be independent from CDK_HASH_KEY_V1_BASE64'
    });
  }
  if (value.ADMIN_HOST && !/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i.test(value.ADMIN_HOST)) {
    context.addIssue({ code: 'custom', path: ['ADMIN_HOST'], message: 'must be a valid hostname' });
  }
}

function isLoopbackDatabase(urlText) {
  const hostname = new URL(urlText).hostname.toLowerCase();
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '[::1]';
}

function databaseHostname(urlText) {
  return new URL(urlText).hostname.replace(/^\[|\]$/g, '');
}

function databaseUsername(urlText) {
  try {
    const url = new URL(urlText);
    decodeURIComponent(url.password);
    return decodeURIComponent(url.username);
  } catch {
    return null;
  }
}

function decodeCertificate(value) {
  const normalized = String(value || '').replace(/\s/g, '');
  if (!normalized || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(normalized)) {
    return null;
  }
  const certificate = Buffer.from(normalized, 'base64').toString('utf8');
  if (!certificate.includes('-----BEGIN CERTIFICATE-----')) return null;
  if (!certificate.includes('-----END CERTIFICATE-----')) return null;
  return certificate;
}

function validateDatabaseConfig(value, context, { urlKey, tlsKey, caKey }) {
  const tlsEnabled = Boolean(value[tlsKey]);
  const caValue = value[caKey];
  const username = databaseUsername(value[urlKey]);
  if (username === null) {
    context.addIssue({
      code: 'custom',
      path: [urlKey],
      message: 'credentials must use valid URL percent-encoding'
    });
  } else if (value.NODE_ENV === 'production' && !username) {
    context.addIssue({
      code: 'custom',
      path: [urlKey],
      message: 'must include a database username in production'
    });
  }
  if (caValue && !tlsEnabled) {
    context.addIssue({
      code: 'custom',
      path: [caKey],
      message: `requires ${tlsKey}=true`
    });
  }
  if (caValue && !decodeCertificate(caValue)) {
    context.addIssue({
      code: 'custom',
      path: [caKey],
      message: 'must be a base64-encoded PEM certificate'
    });
  }
  if (value.NODE_ENV === 'production' && !isLoopbackDatabase(value[urlKey]) && !tlsEnabled) {
    context.addIssue({
      code: 'custom',
      path: [tlsKey],
      message: 'must be true for a non-loopback production MySQL connection'
    });
  }
  if (
    value.NODE_ENV === 'production'
    && !isLoopbackDatabase(value[urlKey])
    && net.isIP(databaseHostname(value[urlKey]))
  ) {
    context.addIssue({
      code: 'custom',
      path: [urlKey],
      message: 'must use a DNS hostname so the TLS certificate identity can be verified'
    });
  }
}

function validateBaseConfig(value, context) {
  validateAdminConfig(value, context);
  validateCdkSecurityConfig(value, context);
  if (value.CDK_DELIVERY_HMAC_KEY_BASE64) {
    try {
      if (Buffer.from(value.CDK_DELIVERY_HMAC_KEY_BASE64, 'base64').length !== 32) throw new Error();
    } catch {
      context.addIssue({
        code: 'custom', path: ['CDK_DELIVERY_HMAC_KEY_BASE64'],
        message: 'must decode to exactly 32 bytes'
      });
    }
    if ([value.CDK_HASH_KEY_V1_BASE64, value.CDK_RECOVERY_KEY_BASE64]
      .includes(value.CDK_DELIVERY_HMAC_KEY_BASE64)) {
      context.addIssue({
        code: 'custom', path: ['CDK_DELIVERY_HMAC_KEY_BASE64'],
        message: 'must be independent from CDK hash and recovery keys'
      });
    }
  }
  if (value.CARD_INTAKE_PAN_HMAC_KEY_BASE64) {
    try {
      if (Buffer.from(value.CARD_INTAKE_PAN_HMAC_KEY_BASE64, 'base64').length !== 32) throw new Error();
    } catch {
      context.addIssue({
        code: 'custom', path: ['CARD_INTAKE_PAN_HMAC_KEY_BASE64'],
        message: 'must decode to exactly 32 bytes'
      });
    }
  }
  if (value.PAYMENT_REFERENCE_HMAC_KEY_BASE64) {
    try {
      if (Buffer.from(value.PAYMENT_REFERENCE_HMAC_KEY_BASE64, 'base64').length !== 32) throw new Error();
    } catch {
      context.addIssue({
        code: 'custom', path: ['PAYMENT_REFERENCE_HMAC_KEY_BASE64'],
        message: 'must decode to exactly 32 bytes'
      });
    }
    if ([value.CDK_HASH_KEY_V1_BASE64, value.CDK_RECOVERY_KEY_BASE64,
      value.CDK_DELIVERY_HMAC_KEY_BASE64, value.CARD_INTAKE_PAN_HMAC_KEY_BASE64]
      .filter(Boolean).includes(value.PAYMENT_REFERENCE_HMAC_KEY_BASE64)) {
      context.addIssue({
        code: 'custom', path: ['PAYMENT_REFERENCE_HMAC_KEY_BASE64'],
        message: 'must be independent from other hashing and recovery keys'
      });
    }
  }
  if (net.isIP(value.HOST) === 0) {
    context.addIssue({
      code: 'custom',
      path: ['HOST'],
      message: 'must be an explicit IPv4 or IPv6 address'
    });
  } else if (
    value.NODE_ENV === 'production'
    && value.HOST !== '127.0.0.1'
    && value.HOST !== '::1'
  ) {
    context.addIssue({
      code: 'custom',
      path: ['HOST'],
      message: 'must use a loopback address in production; expose the service through the reverse proxy'
    });
  }
  validateDatabaseConfig(value, context, {
    urlKey: 'DATABASE_URL',
    tlsKey: 'DATABASE_TLS',
    caKey: 'DATABASE_TLS_CA_BASE64'
  });
}

const schema = baseSchema.superRefine(validateBaseConfig);

const workerSchema = baseSchema.extend({
  WORKER_ID: z.string().trim().min(1).max(128).optional(),
  WORKER_POLL_INTERVAL_MS: z.coerce.number().int().min(100).max(60_000).default(1_000),
  WORKER_LEASE_SECONDS: z.coerce.number().int().min(10).max(3_600).default(60),
  WORKER_CONCURRENCY: z.coerce.number().int().min(1).max(32).default(1),
  PROVIDER_READS_ENABLED: booleanString.default(false),
  PROVIDER_WRITES_ENABLED: booleanString.default(false),
  PROVIDER_CARD_WRITES_ENABLED: booleanString.default(false),
  PROVIDER_RECHARGE_WRITES_ENABLED: booleanString.default(false),
  HNSKJ_API_BASE_URL: z.string().url().default('https://card.hnskj.vip/api/open/v1'),
  HNSKJ_API_KEY: z.string().trim().min(1).optional(),
  ZZSHU_API_BASE_URL: z.string().url().default('https://card.zzshu.pro/api/v1'),
  ZZSHU_API_KEY: z.string().trim().min(1).optional()
}).superRefine(validateBaseConfig);

function databaseConfig(data, { urlKey, tlsKey, caKey }) {
  return {
    url: data[urlKey],
    tls: data[tlsKey] ? {
      enabled: true,
      rejectUnauthorized: true,
      verifyIdentity: true,
      ca: data[caKey] ? decodeCertificate(data[caKey]) : null
    } : {
      enabled: false,
      rejectUnauthorized: true,
      verifyIdentity: true,
      ca: null
    }
  };
}

export function loadConfig(env = process.env) {
  const result = schema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid v1 configuration: ${detail}`);
  }

  return {
    nodeEnv: result.data.NODE_ENV,
    host: result.data.HOST,
    port: result.data.PORT,
    trustProxy: result.data.TRUST_PROXY,
    database: databaseConfig(result.data, {
      urlKey: 'DATABASE_URL',
      tlsKey: 'DATABASE_TLS',
      caKey: 'DATABASE_TLS_CA_BASE64'
    }),
    sessionEncryptionKey: Buffer.from(result.data.SESSION_ENCRYPTION_KEY_BASE64, 'base64'),
    cdkHashKey: Buffer.from(result.data.CDK_HASH_KEY_V1_BASE64, 'base64'),
    cdkRecoveryKey: Buffer.from(result.data.CDK_RECOVERY_KEY_BASE64, 'base64'),
    cdkDeliveryHmacKey: result.data.CDK_DELIVERY_HMAC_KEY_BASE64
      ? Buffer.from(result.data.CDK_DELIVERY_HMAC_KEY_BASE64, 'base64') : null,
    hnskjApiBaseUrl: result.data.HNSKJ_API_BASE_URL,
    hnskjApiKey: result.data.HNSKJ_API_KEY || null,
    cardIntakePanHmacKey: result.data.CARD_INTAKE_PAN_HMAC_KEY_BASE64
      ? Buffer.from(result.data.CARD_INTAKE_PAN_HMAC_KEY_BASE64, 'base64') : null,
    paymentReferenceHmacKey: result.data.PAYMENT_REFERENCE_HMAC_KEY_BASE64
      ? Buffer.from(result.data.PAYMENT_REFERENCE_HMAC_KEY_BASE64, 'base64') : null,
    adminHost: result.data.ADMIN_HOST || null,
    adminPasswordHash: result.data.ADMIN_PASSWORD_HASH || null,
    adminSessionSecret: result.data.ADMIN_SESSION_SECRET_BASE64
      ? Buffer.from(result.data.ADMIN_SESSION_SECRET_BASE64, 'base64')
      : null
  };
}

export function loadMigrationConfig(env = process.env) {
  const result = migrationSchema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid v1 migration configuration: ${detail}`);
  }
  return {
    nodeEnv: result.data.NODE_ENV,
    database: databaseConfig(result.data, {
      urlKey: 'MIGRATION_DATABASE_URL',
      tlsKey: 'MIGRATION_DATABASE_TLS',
      caKey: 'MIGRATION_DATABASE_TLS_CA_BASE64'
    })
  };
}

export function loadRuntimeDatabaseConfig(env = process.env) {
  const result = runtimeDatabaseSchema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid v1 database configuration: ${detail}`);
  }
  return databaseConfig(result.data, {
    urlKey: 'DATABASE_URL',
    tlsKey: 'DATABASE_TLS',
    caKey: 'DATABASE_TLS_CA_BASE64'
  });
}

export function loadBarkNotificationConfig(env = process.env) {
  const result = barkNotificationSchema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid Bark notification configuration: ${detail}`);
  }
  return {
    database: databaseConfig(result.data, {
      urlKey: 'DATABASE_URL',
      tlsKey: 'DATABASE_TLS',
      caKey: 'DATABASE_TLS_CA_BASE64'
    }),
    enabled: result.data.BARK_ENABLED,
    serverUrl: result.data.BARK_SERVER_URL.replace(/\/+$/, ''),
    deviceKey: result.data.BARK_DEVICE_KEY || null,
    group: result.data.BARK_GROUP,
    pollIntervalMs: result.data.BARK_POLL_INTERVAL_MS,
    requestTimeoutMs: result.data.BARK_REQUEST_TIMEOUT_MS,
    maxAttempts: result.data.BARK_MAX_ATTEMPTS
  };
}

export function loadCdkSecurityConfig(env = process.env) {
  const result = cdkSecuritySchema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid CDK security configuration: ${detail}`);
  }
  return {
    cdkHashKey: Buffer.from(result.data.CDK_HASH_KEY_V1_BASE64, 'base64'),
    cdkRecoveryKey: Buffer.from(result.data.CDK_RECOVERY_KEY_BASE64, 'base64')
  };
}

export function loadWorkerConfig(env = process.env) {
  const result = workerSchema.safeParse(env);
  if (!result.success) {
    const detail = result.error.issues
      .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
      .join('; ');
    throw new Error(`Invalid v1 worker configuration: ${detail}`);
  }
  if (result.data.PROVIDER_WRITES_ENABLED) {
    throw new Error(
      'Provider writes remain locked until the Hnskj purchase/card response contract is verified'
    );
  }
  if ((result.data.PROVIDER_READS_ENABLED || result.data.PROVIDER_RECHARGE_WRITES_ENABLED) && !result.data.ZZSHU_API_KEY) {
    throw new Error('ZZSHU_API_KEY is required when PROVIDER_READS_ENABLED=true');
  }
  if ((result.data.PROVIDER_READS_ENABLED || result.data.PROVIDER_CARD_WRITES_ENABLED) && !result.data.HNSKJ_API_KEY) {
    throw new Error('HNSKJ_API_KEY is required when PROVIDER_READS_ENABLED=true');
  }

  return {
    ...loadConfig(env),
    workerId: result.data.WORKER_ID,
    workerPollIntervalMs: result.data.WORKER_POLL_INTERVAL_MS,
    workerLeaseSeconds: result.data.WORKER_LEASE_SECONDS,
    workerConcurrency: result.data.WORKER_CONCURRENCY,
    providerReadsEnabled: result.data.PROVIDER_READS_ENABLED,
    providerWritesEnabled: false,
    providerCardWritesEnabled: result.data.PROVIDER_CARD_WRITES_ENABLED,
    providerRechargeWritesEnabled: result.data.PROVIDER_RECHARGE_WRITES_ENABLED,
    hnskjApiBaseUrl: result.data.HNSKJ_API_BASE_URL,
    hnskjApiKey: result.data.HNSKJ_API_KEY || null,
    zzshuApiBaseUrl: result.data.ZZSHU_API_BASE_URL,
    zzshuApiKey: result.data.ZZSHU_API_KEY || null
  };
}
