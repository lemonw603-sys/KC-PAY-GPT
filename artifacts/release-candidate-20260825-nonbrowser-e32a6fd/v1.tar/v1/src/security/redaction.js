const SENSITIVE_KEY = /(?:api.?key|authorization|password|secret|token|session|cvv|cvc|card.?number|card.?no|pan|cdk|recharge.?card.?key|credential|ciphertext)/i;

function redactText(value) {
  return String(value)
    .replace(/nhs_[A-Za-z0-9._-]+/g, '[REDACTED_API_KEY]')
    .replace(/Bearer\s+[^\s]+/gi, 'Bearer [REDACTED]')
    .replace(/\b(?:PJ-[A-HJ-KM-NP-Z2-9]{5}(?:-[A-HJ-KM-NP-Z2-9]{5}){3}|VCK-[A-Z0-9]{4}(?:-[A-Z0-9]{4}){2,4})\b/gi, '[REDACTED_CDK]')
    .replace(/\beyJ[A-Za-z0-9_-]+(?:\.[A-Za-z0-9_-]+){2,4}\b/g, '[REDACTED_TOKEN]')
    .replace(/\b\d{12,19}\b/g, (match) => `****${match.slice(-4)}`)
    .replace(
      /\b(api[\s_-]?key|authorization|password|secret|access[\s_-]?token|session[\s_-]?token|cvv|cvc|card[\s_-]?(?:number|no)|pan)\b(\s*[:=]\s*)("[^"]*"|'[^']*'|[^\s,;}]+)/gi,
      (_match, name, separator) => `${name}${separator}[REDACTED]`
    )
    .slice(0, 1_000);
}

export function redactSensitiveText(value) {
  return redactText(value);
}

export function redactSensitiveFields(value, key = '') {
  if (SENSITIVE_KEY.test(key)) return '[REDACTED]';
  if (value == null || typeof value === 'boolean' || typeof value === 'number') return value;
  if (typeof value === 'string') return redactText(value);
  if (Array.isArray(value)) return value.slice(0, 100).map((item) => redactSensitiveFields(item));
  if (typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value).slice(0, 200).map(([childKey, child]) => [
        childKey,
        redactSensitiveFields(child, childKey)
      ])
    );
  }
  return String(value).slice(0, 1_000);
}
