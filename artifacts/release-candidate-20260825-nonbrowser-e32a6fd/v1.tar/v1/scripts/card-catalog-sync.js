import { isEnvTrue, loadConfig } from '../src/config.js';
import { createDatabasePool } from '../src/db/pool.js';
import { HnskjCardProvider } from '../src/providers/index.js';
import { syncCardCatalog } from '../src/services/card-catalog-sync-service.js';
import { createCardIntakeService } from '../src/services/card-intake-service.js';
import { createCardIntakeRepository } from '../src/db/repositories/card-intake-repository.js';
import { refreshProviderSnapshot } from '../src/services/card-provider-snapshot-service.js';
import { createProviderBalanceSnapshotService } from '../src/services/provider-balance-snapshot-service.js';
import { resolveCurrentCardProviderAccountId } from '../src/services/provider-route-service.js';

if (isEnvTrue(process.env.PROVIDER_WRITES_ENABLED) || isEnvTrue(process.env.PROVIDER_CARD_WRITES_ENABLED)) {
  throw new Error('Card catalog sync refuses to run with provider writes enabled');
}

const config = loadConfig();
const pool = createDatabasePool(config.database);
const providerAccountId = await resolveCurrentCardProviderAccountId(pool);
if (!providerAccountId) throw new Error('No active production card provider route');
const provider = new HnskjCardProvider({
  baseUrl: process.env.HNSKJ_API_BASE_URL || 'https://card.hnskj.vip/api/open/v1',
  apiKey: String(process.env.HNSKJ_API_KEY || '')
});
const [[settings]] = await pool.query(
  `SELECT MAX(CASE WHEN setting_key = 'default_card_type_id' THEN setting_value END) AS card_type_id,
          MAX(CASE WHEN setting_key = 'default_minimum_required_card_balance' THEN setting_value END) AS minimum_balance
   FROM app_settings`
);
const intake = createCardIntakeService({
  provider,
  repository: createCardIntakeRepository({ pool }),
  providerAccountId,
  sessionEncryptionKey: config.sessionEncryptionKey,
  assumeDedicatedAccount: true,
  validationRules: {
    allowedCardTypeIds: [String(settings.card_type_id || '')],
    minimumBalance: String(settings.minimum_balance || '')
  }
});
const balanceSnapshots = createProviderBalanceSnapshotService({ pool });

async function markProviderSnapshotHealth({ status, message }) {
  const dedupeKey = 'provider-snapshot:hnskj';
  if (status === 'OPEN') {
    await pool.query(
      `INSERT INTO operator_alerts
       (id, alert_type, dedupe_key, severity, title, message, status)
       VALUES (UUID(), 'PROVIDER_SNAPSHOT_STALE', ?, 'critical', '卡台余额同步异常', ?, 'OPEN')
       ON DUPLICATE KEY UPDATE severity = VALUES(severity), title = VALUES(title),
         message = VALUES(message), status = 'OPEN', acknowledged_at = NULL`,
      [dedupeKey, message]
    );
  } else {
    await pool.query(
      `UPDATE operator_alerts SET status = 'RESOLVED', acknowledged_at = CURRENT_TIMESTAMP(3)
       WHERE dedupe_key = ? AND status = 'OPEN'`, [dedupeKey]
    );
  }
}

try {
  // Catalog synchronization is read-only. Refresh the provider balance/rules
  // snapshot here as well so the admin affordability view is not dependent on
  // the write-enabled card-stock runner.
  let providerSnapshot;
  try {
    providerSnapshot = await refreshProviderSnapshot(pool, provider, {
      balanceSnapshotService: balanceSnapshots
    });
    await markProviderSnapshotHealth({ status: 'RESOLVED' });
  } catch (error) {
    const code = String(error?.code || error?.kind || 'PROVIDER_SNAPSHOT_SYNC_FAILED').slice(0, 80);
    await markProviderSnapshotHealth({
      status: 'OPEN',
      message: `HNSKJ 余额/开卡规则只读同步失败（${code}）。后台不得将旧快照视为实时数据。`
    });
    throw error;
  }
  const catalog = await syncCardCatalog({ pool, provider, intake });
  console.log(JSON.stringify({ ...catalog, providerSnapshotSyncedAt: providerSnapshot.syncedAt }));
} finally {
  await pool.end();
}
